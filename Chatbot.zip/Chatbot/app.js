document.getElementById('send-btn').addEventListener('click', sendMessage);
document.getElementById('voice-btn').addEventListener('click', startVoiceInput);

function sendMessage() {
    const input = document.getElementById('user-input');
    const chatHistory = document.getElementById('chat-history');
    const userMessage = input.value;

    if (userMessage.trim()) {
        const messageDiv = document.createElement('div');
        messageDiv.textContent = `You: ${userMessage}`;
        messageDiv.className = 'mb-2';
        chatHistory.appendChild(messageDiv);
        input.value = '';

        // Simulate bot response
        setTimeout(() => {
            const botMessage = document.createElement('div');
            botMessage.textContent = 'Bot: Thank you for your message!';
            botMessage.className = 'text-primary mb-2';
            chatHistory.appendChild(botMessage);
        }, 1000);
    }
}

function startVoiceInput() {
    alert('Voice input is under development.');
}
